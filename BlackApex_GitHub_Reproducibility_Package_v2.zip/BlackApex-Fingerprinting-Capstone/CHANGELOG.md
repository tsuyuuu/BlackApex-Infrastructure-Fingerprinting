# Changelog

## v2 — Research-package audit correction (2026-11-14)

- Corrected `verification_post` in `heldout_validation.py` to require a
  `fetch('/verify-turnstile', {method: 'POST'})` source pattern, using the
  existing structural detector source check. Previously the rule could match
  the endpoint string without requiring the HTTP method.
- Updated the minimal synthetic positive fixture to include `method:'POST'`.
- Added a GET-only synthetic negative control with the other feature names.
- Preserved original samples and previously recorded Codespaces output. That
  user-reported output predates the corrected rule; re-run the full OneDrive
  saved HTML to reproduce a corrected-rule positive on that source.
- This remains a lightweight static source-pattern detector, not a semantic
  JavaScript parser, malware classifier, or evidence of backend execution.
